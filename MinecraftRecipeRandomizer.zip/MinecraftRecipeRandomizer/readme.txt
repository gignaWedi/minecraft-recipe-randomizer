Author: gignaWedi
Descr: Modless Recipe Randomizer for 1.14

Works similiar to SethBling's MinecraftLootRandomizer, just for crafting recipes instead of loot tables
(The pack will also chose and display a random seed if none is given)

Credits to SethBling for inspiration and PrismarineJS for extracted recipe data

Future:
Add all recipe types (currently, only crafting recipes are available, no smelting)

<3

